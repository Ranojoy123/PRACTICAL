package basics;

public class NullExample {

	public static void main(String[] args) {
		 System.out.println(null == null); 
		 System.out.println(null != null); 
	}
}
