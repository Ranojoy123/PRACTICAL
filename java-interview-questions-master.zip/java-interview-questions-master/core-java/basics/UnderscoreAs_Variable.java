package basics;

public class UnderscoreAs_Variable {

	public static void main(String[] args) {
		int _ = 10;
		System.out.println(_);
	}
}
